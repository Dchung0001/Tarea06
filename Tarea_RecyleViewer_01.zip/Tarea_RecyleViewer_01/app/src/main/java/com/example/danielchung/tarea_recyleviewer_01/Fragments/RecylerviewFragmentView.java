package com.example.danielchung.tarea_recyleviewer_01.Fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.danielchung.tarea_recyleviewer_01.Adapter.cachorro_Adaptador;
import com.example.danielchung.tarea_recyleviewer_01.Pojo.Cachorro_Perfil;
import com.example.danielchung.tarea_recyleviewer_01.Presentador.IRecylerViewFragmentPresent;
import com.example.danielchung.tarea_recyleviewer_01.Presentador.RecylerViewFragmentPresent;
import com.example.danielchung.tarea_recyleviewer_01.R;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class RecylerviewFragmentView extends Fragment implements IRecyclerviewFragmentView  {

    ArrayList<Cachorro_Perfil> Cachorro;
    private RecyclerView lstCachorro;
    private IRecylerViewFragmentPresent present;
    /*
    public RecylerviewFragmentView() {
        // Required empty public constructor
    }
    */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_fragment1, container, false);
        View v=inflater.inflate(R.layout.fragment_fragment1,container,false);

        lstCachorro=(RecyclerView)v.findViewById(R.id.RcCachorro);
        present=new RecylerViewFragmentPresent( this,getContext());
        return v;

        }

    public void InicialAdaptador(){
        cachorro_Adaptador Adaptador=new cachorro_Adaptador(Cachorro,getActivity());
        lstCachorro.setAdapter(Adaptador);
    }

    @Override
    public void generarLinearLayoutVertical() {
        LinearLayoutManager llm=new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        lstCachorro.setLayoutManager(llm);
    }

    @Override
    public cachorro_Adaptador crearAdaptador(ArrayList<Cachorro_Perfil> cachorro) {
        cachorro_Adaptador Adaptador=new cachorro_Adaptador(cachorro,getActivity());
        return Adaptador;
    }

    @Override
    public void inicializarAdaptadorRV(cachorro_Adaptador adaptador) {
        lstCachorro.setAdapter(adaptador);
    }
}
