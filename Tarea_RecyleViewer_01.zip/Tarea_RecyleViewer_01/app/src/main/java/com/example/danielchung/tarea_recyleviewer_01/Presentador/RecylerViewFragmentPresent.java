package com.example.danielchung.tarea_recyleviewer_01.Presentador;

import android.content.Context;


import com.example.danielchung.tarea_recyleviewer_01.Db.ConstructorCachorro;
import com.example.danielchung.tarea_recyleviewer_01.Fragments.IRecyclerviewFragmentView;
import com.example.danielchung.tarea_recyleviewer_01.Pojo.Cachorro_Perfil;

import java.util.ArrayList;

public class RecylerViewFragmentPresent implements IRecylerViewFragmentPresent {

    private IRecyclerviewFragmentView iRecyclerviewFragmentView;
    private Context context;
    private ConstructorCachorro constructorContactos;
    private ArrayList<Cachorro_Perfil> contactos;

    public RecylerViewFragmentPresent(IRecyclerviewFragmentView iRecyclerviewFragmentView, Context context)
    {
        this.iRecyclerviewFragmentView=iRecyclerviewFragmentView;
        this.context=context;
        obtenerContactosBaseDatos();
    }

    @Override
    public void obtenerContactosBaseDatos() {
        constructorContactos=new ConstructorCachorro(context);
        contactos=constructorContactos.obtenerDatos();
        mostrarContactosRV();
    }

    @Override
    public void mostrarContactosRV() {
        iRecyclerviewFragmentView.inicializarAdaptadorRV(iRecyclerviewFragmentView.crearAdaptador(contactos));
        iRecyclerviewFragmentView.generarLinearLayoutVertical();
    }
}