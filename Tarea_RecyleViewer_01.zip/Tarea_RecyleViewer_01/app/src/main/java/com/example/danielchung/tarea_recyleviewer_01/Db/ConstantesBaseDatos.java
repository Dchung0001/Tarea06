package com.example.danielchung.tarea_recyleviewer_01.Db;

public class ConstantesBaseDatos {

    public static final String DATABASE_NAME="Cachorros";
    public static final int DATABASE_VERSION=1;

    public static final String TABLE_CACHORROS="Cachorro";
    public static final String TABLE_CACHORROS_ID="id";
    public static final String TABLE_CACHORROS_NOMBRE="nombre";
    public static final String TABLE_CACHORROS_FOTO="foto";

    public static final String TABLE_LIKE_CACHORROS="cachorro_like";
    public static final String TABLE_LIKE_CACHORROS_ID="id";
    public static final String TABLE_LIKE_CACHORROS_ID_CACHORROS="id_cachorro";
    public static final String TABLE_LIKE_CACHORROS_NUMERO_LIKES="numero_likes";

}
