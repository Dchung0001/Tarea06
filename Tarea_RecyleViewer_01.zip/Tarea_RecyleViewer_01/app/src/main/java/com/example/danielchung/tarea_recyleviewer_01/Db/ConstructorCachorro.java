package com.example.danielchung.tarea_recyleviewer_01.Db;

import android.content.ContentValues;
import android.content.Context;

import com.example.danielchung.tarea_recyleviewer_01.Pojo.Cachorro_Perfil;
import com.example.danielchung.tarea_recyleviewer_01.R;

import java.util.ArrayList;

public class ConstructorCachorro {

    private static final int LIKES =1;
    Context context;

    public ConstructorCachorro(Context context) {
        this.context=context;
    }

    public ArrayList<Cachorro_Perfil> obtenerDatos(){
        BaseDatos db=new BaseDatos(context);
        insertarCachorro(db);
        return db.ObtenerTodosLosCachorros();
    }

    public void insertarCachorro(BaseDatos db)
    {

        ContentValues contentValues=new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_CACHORROS_NOMBRE,"KERO");
        contentValues.put(ConstantesBaseDatos.TABLE_CACHORROS_FOTO,R.drawable.cachorro1);
        db.InsertarCachorro(contentValues);

        contentValues=new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_CACHORROS_NOMBRE,"Rayo");
        contentValues.put(ConstantesBaseDatos.TABLE_CACHORROS_FOTO,R.drawable.cachorro2);
        db.InsertarCachorro(contentValues);

        contentValues=new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_CACHORROS_NOMBRE,"Pulga");
        contentValues.put(ConstantesBaseDatos.TABLE_CACHORROS_FOTO,R.drawable.cachorro3);
        db.InsertarCachorro(contentValues);

        contentValues=new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_CACHORROS_NOMBRE,"Toro");
        contentValues.put(ConstantesBaseDatos.TABLE_CACHORROS_FOTO,R.drawable.cachorro4);
        db.InsertarCachorro(contentValues);

        contentValues=new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_CACHORROS_NOMBRE,"Lana");
        contentValues.put(ConstantesBaseDatos.TABLE_CACHORROS_FOTO,R.drawable.cachorro5);
        db.InsertarCachorro(contentValues);

    }

    public void DarLikeAlCachorro(Cachorro_Perfil cachorro_perfil)
    {
        BaseDatos db=new BaseDatos(context);
        ContentValues contentValues=new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_LIKE_CACHORROS_ID_CACHORROS,cachorro_perfil.getId());
        contentValues.put(ConstantesBaseDatos.TABLE_LIKE_CACHORROS_NUMERO_LIKES,LIKES);
        db.InsertarLikeContacto(contentValues);
    }

    public int ObtenerLikesCachorro(Cachorro_Perfil Cachorro)
    {
        BaseDatos db=new BaseDatos(context);
        return db.ObtenerLikeCachorros(Cachorro);
    }
}
