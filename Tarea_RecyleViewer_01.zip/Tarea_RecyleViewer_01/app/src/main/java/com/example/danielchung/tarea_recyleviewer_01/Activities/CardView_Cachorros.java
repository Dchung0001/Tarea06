package com.example.danielchung.tarea_recyleviewer_01.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.danielchung.tarea_recyleviewer_01.R;

public class CardView_Cachorros extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_view__cachorros);
    }
}
