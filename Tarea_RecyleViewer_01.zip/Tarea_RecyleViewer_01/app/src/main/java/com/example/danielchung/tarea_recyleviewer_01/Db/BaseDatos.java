package com.example.danielchung.tarea_recyleviewer_01.Db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

import com.example.danielchung.tarea_recyleviewer_01.Pojo.Cachorro_Perfil;

import java.util.ArrayList;

public class BaseDatos extends SQLiteOpenHelper {

    private Context context;

    public BaseDatos(@Nullable Context context) {
        super(context, ConstantesBaseDatos.DATABASE_NAME, null, ConstantesBaseDatos.DATABASE_VERSION);
        this.context=context;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

    // Tabla de Cachorros
        String QueryCrearTablaCachorro="CREATE TABLE "+ConstantesBaseDatos.TABLE_CACHORROS
                +"("+ConstantesBaseDatos.TABLE_CACHORROS_ID+" INTEGER PRIMARY KEY AUTOINCREMENT"+","+
                ConstantesBaseDatos.TABLE_CACHORROS_NOMBRE+" TEXT, "+
                ConstantesBaseDatos.TABLE_CACHORROS_FOTO+" INTEGER "+
                ")";
        db.execSQL(QueryCrearTablaCachorro);

    //Tabla de Like para los cachorros

        String QueryCrearTablaLikesCachorro="CREATE TABLE "+ConstantesBaseDatos.TABLE_LIKE_CACHORROS
                +"("+ConstantesBaseDatos.TABLE_LIKE_CACHORROS_ID+" INTEGER PRIMARY KEY AUTOINCREMENT"+","+
                ConstantesBaseDatos.TABLE_LIKE_CACHORROS_ID_CACHORROS +" INTEGER," +
                ConstantesBaseDatos.TABLE_LIKE_CACHORROS_NUMERO_LIKES +" INTEGER, " +
                " FOREIGN KEY ("+ ConstantesBaseDatos.TABLE_LIKE_CACHORROS_ID_CACHORROS +")"+
                " REFERENCES " + ConstantesBaseDatos.TABLE_CACHORROS+"("+ ConstantesBaseDatos.TABLE_CACHORROS_ID +")"+
                ")";
        db.execSQL(QueryCrearTablaLikesCachorro);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+ ConstantesBaseDatos.TABLE_CACHORROS);
        db.execSQL("DROP TABLE IF EXISTS "+ ConstantesBaseDatos.TABLE_LIKE_CACHORROS);
        onCreate(db);
    }

    public ArrayList<Cachorro_Perfil> ObtenerTodosLosCachorros()
    {
        ArrayList<Cachorro_Perfil> Cachorro=new ArrayList<>();
        String Query="SELECT * FROM "+ ConstantesBaseDatos.TABLE_CACHORROS;
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor Registro=db.rawQuery(Query,null);

        while (Registro.moveToNext())
        {
            Cachorro_Perfil CachorroActual=new Cachorro_Perfil();
            CachorroActual.setId(Registro.getInt(0));
            CachorroActual.setStrNomCahorro(Registro.getString(1));
            CachorroActual.setImgFoto(Registro.getInt(2));


            String QueryLikes="SELECT COUNT ("+ ConstantesBaseDatos.TABLE_LIKE_CACHORROS_NUMERO_LIKES+") AS Like "+
                    "FROM "+ConstantesBaseDatos.TABLE_LIKE_CACHORROS+" "+
                    "WHERE "+ConstantesBaseDatos.TABLE_LIKE_CACHORROS_ID_CACHORROS+"="+CachorroActual.getId();

            Cursor reglikes=db.rawQuery(QueryLikes,null);

            if (reglikes.moveToNext())
            {
                CachorroActual.setIntEstrella(reglikes.getInt(0));
            }
            else
            {
                CachorroActual.setIntEstrella(0);
            }

            Cachorro.add(CachorroActual);

        }
        db.close();
        return Cachorro;
    }

    public void InsertarCachorro(ContentValues contentValues)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.TABLE_CACHORROS,null,contentValues);
        db.close();
    }

    public void InsertarLikeContacto(ContentValues contentValues)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.TABLE_LIKE_CACHORROS,null,contentValues);
        db.close();
    }

    public int ObtenerLikeCachorros(Cachorro_Perfil cachorro_perfil)
    {
        int likes=0;
        String Query="SELECT COUNT("+ ConstantesBaseDatos.TABLE_LIKE_CACHORROS_NUMERO_LIKES +") " +
                "FROM "+ ConstantesBaseDatos.TABLE_LIKE_CACHORROS +
                " WHERE "+ConstantesBaseDatos.TABLE_LIKE_CACHORROS_ID_CACHORROS+"="+cachorro_perfil.getId();
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor Registro1=db.rawQuery(Query,null);

        if (Registro1.moveToNext())
        {
            likes=Registro1.getInt(0);
        }
        db.close();
        return likes;

    }
}
