package com.example.danielchung.tarea_recyleviewer_01.Presentador;

public interface IRecylerViewFragmentPresent {

    public void obtenerContactosBaseDatos();
    public void mostrarContactosRV();
}
