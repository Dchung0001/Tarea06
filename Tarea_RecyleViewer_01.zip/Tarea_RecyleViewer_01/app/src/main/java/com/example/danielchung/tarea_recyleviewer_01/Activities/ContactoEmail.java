package com.example.danielchung.tarea_recyleviewer_01.Activities;

import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.danielchung.tarea_recyleviewer_01.R;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class ContactoEmail extends AppCompatActivity {

    private EditText txtCorreo;
    private EditText txtComent;
    private EditText txtNombre;
    private Button btnEnviar;
    private Session session;
    String Email="tareadck@gmail.com";
    String Contrasena="Abc_2356";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacto_email);

        txtCorreo=(EditText)findViewById(R.id.txtCorreo);
        txtNombre=(EditText)findViewById(R.id.txtNombre);
        txtComent=(EditText)findViewById(R.id.txtComentario);
        btnEnviar=(Button)findViewById(R.id.btnEnviar);

        Toolbar mib1=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(mib1);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EnviarEmail();
            }
        });

    }

    public void EnviarEmail()
    {
        StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Properties properties=new Properties();
        properties.put("mail.smtp.host","smtp.gmail.com");
        properties.put("mail.smtp.socketFactory.port", "465");
        properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.port", "465");

        try{
            session = Session.getDefaultInstance(properties,
                    new Authenticator() {
                        //Authenticating the password
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(Email,Contrasena);
                        }
                    });

            if(session!=null)
            {
                MimeMessage message=new MimeMessage(session);
                message.setFrom(new InternetAddress(Email));
                message.setSubject("Comentario de:"+txtNombre.getText().toString());
                message.setRecipients(javax.mail.Message.RecipientType.TO,InternetAddress.parse(txtCorreo.getText().toString()));
                message.setContent(txtComent.getText().toString(),"text/html; charset=utf-8");
                Transport.send(message);
                Toast.makeText(ContactoEmail.this,"Mensaje Enviado",Toast.LENGTH_LONG).show();
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
