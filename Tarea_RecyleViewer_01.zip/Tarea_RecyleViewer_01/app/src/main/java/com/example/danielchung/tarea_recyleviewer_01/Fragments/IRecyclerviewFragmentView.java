package com.example.danielchung.tarea_recyleviewer_01.Fragments;

import com.example.danielchung.tarea_recyleviewer_01.Adapter.cachorro_Adaptador;
import com.example.danielchung.tarea_recyleviewer_01.Pojo.Cachorro_Perfil;

import java.util.ArrayList;

public interface IRecyclerviewFragmentView {
    public void generarLinearLayoutVertical();
    public cachorro_Adaptador crearAdaptador(ArrayList<Cachorro_Perfil> contactos);
    public  void inicializarAdaptadorRV(cachorro_Adaptador adaptador);
}
